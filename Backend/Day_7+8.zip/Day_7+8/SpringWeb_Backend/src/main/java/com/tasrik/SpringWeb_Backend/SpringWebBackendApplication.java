package com.tasrik.SpringWeb_Backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringWebBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringWebBackendApplication.class, args);
	}

}
