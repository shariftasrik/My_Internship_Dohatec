export default function Home() {
  return <h1>Hello from Home Page</h1>;
}
