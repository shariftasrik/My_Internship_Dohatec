export default function AddProduct() {
  return (
    <div className="flex items-center justify-center h-screen bg-gray-100 dark:bg-gray-900">
      <h2 className="text-3xl text-gray-800 dark:text-white">
        Add Product Coming Soon...
      </h2>
    </div>
  );
}
